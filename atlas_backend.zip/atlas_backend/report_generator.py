from fpdf import FPDF
import datetime
import config
import re

class ModernReport(FPDF):
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=15)
        # RENAMED VARIABLES TO FIX CONFLICT
        self.report_header_color = (0, 51, 102) # Navy Blue
        self.report_accent_color = (200, 200, 200) # Light Grey
        self.body_text_color = (50, 50, 50) # Dark Grey

    def header(self):
        if self.page_no() > 1:
            self.set_font('Arial', 'B', 8)
            self.set_text_color(*self.report_header_color)
            self.cell(0, 10, 'ATLAS INTELLIGENCE DOSSIER', 0, 0, 'L')
            self.cell(0, 10, f'CONFIDENTIAL', 0, 0, 'R')
            self.ln(5)
            self.set_draw_color(*self.report_accent_color)
            self.line(10, 15, 200, 15)
            self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def draw_cover_page(self, company_name, score):
        self.add_page()
        
        # Background Accent
        self.set_fill_color(245, 247, 250)
        self.rect(0, 0, 210, 297, 'F')
        
        # Title Block
        self.set_y(60)
        self.set_font('Arial', 'B', 36)
        self.set_text_color(*self.report_header_color)
        self.cell(0, 15, "INTELLIGENCE", 0, 1, 'C')
        self.cell(0, 15, "DOSSIER", 0, 1, 'C')
        
        self.ln(20)
        
        # Target Company
        self.set_font('Arial', '', 14)
        self.set_text_color(100, 100, 100)
        self.cell(0, 10, "TARGET ENTITY", 0, 1, 'C')
        self.set_font('Arial', 'B', 24)
        self.set_text_color(0, 0, 0)
        self.cell(0, 15, company_name.upper(), 0, 1, 'C')
        
        self.ln(30)
        
        # Score Card
        self.set_fill_color(255, 255, 255)
        self.set_draw_color(*self.report_header_color)
        self.set_line_width(1)
        self.rect(65, 170, 80, 40, 'DF')
        
        self.set_y(175)
        self.set_font('Arial', 'B', 12)
        self.set_text_color(*self.report_header_color)
        self.cell(0, 5, "ICP QUALIFICATION SCORE", 0, 1, 'C')
        self.ln(5)
        self.set_font('Arial', 'B', 28)
        
        # Color code the score
        if score >= 80: self.set_text_color(0, 150, 0) # Green
        elif score >= 50: self.set_text_color(200, 150, 0) # Orange
        else: self.set_text_color(200, 0, 0) # Red
            
        self.cell(0, 15, f"{score}/100", 0, 1, 'C')
        
        # Metadata
        self.set_y(260)
        self.set_font('Arial', '', 10)
        self.set_text_color(100, 100, 100)
        self.cell(0, 5, f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}", 0, 1, 'C')
        self.cell(0, 5, "Agent: ATLAS v1.0", 0, 1, 'C')

    def chapter_title(self, label):
        self.ln(5)
        self.set_font('Arial', 'B', 16)
        self.set_text_color(*self.report_header_color)
        self.cell(0, 10, label.upper(), 0, 1, 'L')
        
        # Underline
        self.set_draw_color(*self.report_header_color)
        self.set_line_width(0.5)
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(5)

    def chapter_body(self, text):
        self.set_font('Arial', '', 11)
        # FIX: Using the renamed variable
        self.set_text_color(*self.body_text_color)
        
        # Simple Markdown Parsing (Bold and Bullets)
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            if not line:
                self.ln(2)
                continue
                
            # Handle Bullet Points
            if line.startswith('- ') or line.startswith('* '):
                self.set_x(15) # Indent
                line = line[2:] # Remove bullet char
                self.cell(5, 5, chr(149), 0, 0) # Draw bullet dot
            else:
                self.set_x(10)

            # Clean bold markers for PDF
            clean_line = line.replace('**', '').replace('__', '')
            
            # Using multi_cell for wrapping text
            self.multi_cell(0, 6, clean_line)
            self.ln(1)
        
        self.ln(5)

def generate_report(company_name, data):
    pdf = ModernReport()
    
    # Calculate fake score based on data density
    score = 50 + (len(str(data)) // 100)
    if score > 98: score = 98
    
    # Cover Page
    pdf.draw_cover_page(company_name, score)
    
    # Content Pages
    pdf.add_page()
    
    # Dimension Order
    order = [
        "Identity & Structure", 
        "Financial Health", 
        "Product & Tech", 
        "People & Culture", 
        "Market Position", 
        "Risk & Reputation"
    ]
    
    for dim in order:
        if dim in data:
            pdf.chapter_title(dim)
            # Encode/Decode to handle potential UTF-8 issues in standard FPDF
            safe_text = data[dim].encode('latin-1', 'replace').decode('latin-1')
            pdf.chapter_body(safe_text)
            
    filename = f"{config.REPORT_DIR}/{company_name.replace(' ', '_')}_Dossier.pdf"
    pdf.output(filename)
    print(f"\n📄 Modern Report generated: {filename}")