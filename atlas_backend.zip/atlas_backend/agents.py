from llm_engine import LLMEngine
from browser_engine import ResearchBrowser
import json
import time

class MacroPlanner:
    def __init__(self, company_name):
        self.llm = LLMEngine()
        self.company = company_name

    def create_plan(self):
        """
        MACRO STEP: Generates a specific Todo List for this company.
        """
        print(f"\n🗺️  MACRO PLANNER: Charting course for {self.company}...")
        prompt = f"""
        I need to build a comprehensive intelligence dossier on '{self.company}'.
        Generate a JSON research plan covering these 6 dimensions:
        1. Identity & Structure
        2. Financial Health
        3. Product & Tech
        4. People & Culture
        5. Market Position
        6. Risk & Reputation

        For EACH dimension, provide a 'focus_topic' specifically tailored to what we likely don't know about {self.company}.
        
        Format:
        {{
            "dimensions": [
                {{ "name": "Financial Health", "focus": "Find revenue estimates and funding rounds" }},
                ...
            ]
        }}
        """
        plan = self.llm.generate_json(prompt)
        
        # Fallback if LLM fails to generate valid JSON plan
        if not plan or "dimensions" not in plan:
            print("⚠️ Macro Plan generation failed. Using default strategy.")
            return {
                "dimensions": [
                    {"name": "Identity & Structure", "focus": "legal name, headquarters, subsidiaries, ownership"},
                    {"name": "Financial Health", "focus": "revenue estimates, funding rounds, investors, profitability"},
                    {"name": "Product & Tech", "focus": "core products, technology stack, patents, open source"},
                    {"name": "People & Culture", "focus": "leadership team, employee count, glassdoor reviews, hiring"},
                    {"name": "Market Position", "focus": "top competitors, market share, target audience"},
                    {"name": "Risk & Reputation", "focus": "lawsuits, security breaches, negative news, regulatory issues"}
                ]
            }
        return plan

class MicroAgent:
    def __init__(self, browser, company):
        self.llm = LLMEngine()
        self.browser = browser
        self.company = company

    def execute_task(self, dimension_name, focus_topic):
        """
        MICRO LOOP: Query -> Search -> Summarize -> Validate -> Repeat
        """
        print(f"\n🕵️  MICRO AGENT: Researching {dimension_name} ({focus_topic})")
        
        summary_so_far = ""
        attempts = 0
        max_attempts = 2 # Repeat loop limit
        
        while attempts < max_attempts:
            # 1. Query Builder
            query_prompt = f"""
            Task: Find info on '{focus_topic}' for '{self.company}'.
            Previous info found: "{summary_so_far}"
            Generate 2 distinct Google search queries to find MISSING or deeper info.
            Return JSON: {{ "queries": ["query1", "query2"] }}
            """
            plan = self.llm.generate_json(query_prompt)
            
            # Robust query extraction
            queries = plan.get("queries")
            if not isinstance(queries, list):
                queries = [f"{self.company} {focus_topic}", f"{self.company} {dimension_name} data"]

            step_findings = []
            
            # 2. Execution Loop
            for query in queries:
                # Get both Google Page Text (AI Overview) AND Links
                serp_text, urls = self.browser.search_google(query)
                
                # A. Analyze Google Page First (AI Overview / Snippets)
                if serp_text:
                    serp_summary = self.llm.generate(f"Extract facts about '{focus_topic}' from this Google Search Page text: {serp_text[:4000]}")
                    if "no relevant" not in serp_summary.lower():
                        step_findings.append(f"[Google Summary]: {serp_summary}")

                # B. Surf Websites (Deep Dive)
                for url in urls[:1]: 
                    text = self.browser.scrape_text(url)
                    if not text or len(text) < 100: continue
                    
                    fact = self.llm.generate(f"Extract specific facts regarding '{focus_topic}' for '{self.company}' from this website text: {text[:6000]}")
                    if "no relevant" not in fact.lower():
                        step_findings.append(f"[Source: {url}] {fact}")

            if step_findings:
                new_info = "\n".join(step_findings)
                summary_so_far += f"\n{new_info}"
            
            # 3. Validation (The "Repeat 🔁" Logic)
            if not summary_so_far:
                attempts += 1
                continue

            validation_prompt = f"""
            We need info on: {focus_topic}
            We have: {summary_so_far}
            
            Is this sufficient? Reply YES or NO.
            """
            check = self.llm.generate(validation_prompt)
            
            if "YES" in check.upper():
                print(f"✅  Validated: Sufficient data found.")
                break
            else:
                print(f"🔁  Validation: Insufficient data. Refining queries...")
                attempts += 1

        # Final Polish for this dimension
        if not summary_so_far: return "No significant data found."
        
        final_summary = self.llm.generate(
            f"""
            Synthesize this raw data into a professional, well-formatted report section about {dimension_name}.
            
            Formatting Rules:
            - Use bullet points for lists (start lines with "- ").
            - Use **Bold** for key metrics, names, or numbers.
            - Keep it dense with facts, avoiding fluff.
            - Cite specific sources if available.

            Raw Data:
            {summary_so_far}
            """
        )
        return final_summary

class AutonomousLeadAgent:
    def __init__(self, company_name):
        self.company = company_name
        self.browser = ResearchBrowser()
        self.planner = MacroPlanner(company_name)
        self.data = {}
        
    def run_pipeline(self):
        # Phase 1: Macro Plan
        plan = self.planner.create_plan()
        tasks = plan.get("dimensions", [])
        
        # Phase 2: One by One Execution
        worker = MicroAgent(self.browser, self.company)
        
        for task in tasks:
            dim_name = task.get("name")
            focus = task.get("focus")
            
            # Run the Micro-Loop
            result = worker.execute_task(dim_name, focus)
            self.data[dim_name] = result
            
        self.browser.close()
        return self.data