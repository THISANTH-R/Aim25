import time
import shutil
import os
import json
import re
import ast
import ollama
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

# --- ⚙️ CONFIGURATION ---
MODEL_NAME = "qwen3:4b-instruct-2507-q4_K_M" 
BRAVE_PATH = "/opt/brave.com/brave/brave"
ORIGINAL_PROFILE = "/home/gokul/.config/BraveSoftware/Brave-Browser"
TEMP_PROFILE = "/tmp/Brave-Autonomous-Agent-V3"

class IntelligentAgent:
    def __init__(self):
        self.driver = self._setup_driver()
        self.action_log = [] # Short term memory
        self.banned_ids = [] # Elements that trap us
        self.target_url = None

    def _setup_driver(self):
        if os.path.exists(TEMP_PROFILE):
            try: shutil.rmtree(TEMP_PROFILE, ignore_errors=True)
            except: pass
            
        def ignore_cache(dir, files):
            return [f for f in files if "Cache" in f or "lock" in f]
            
        try: shutil.copytree(ORIGINAL_PROFILE, TEMP_PROFILE, ignore=ignore_cache)
        except: pass

        options = Options()
        options.binary_location = BRAVE_PATH
        options.add_argument(f"--user-data-dir={TEMP_PROFILE}")
        options.add_argument("--profile-directory=Default")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("detach", True)
        
        try: service = Service(ChromeDriverManager(driver_version="143").install())
        except: service = Service()

        driver = webdriver.Chrome(service=service, options=options)
        driver.set_window_size(1400, 1000)
        return driver

    def _extract_json(self, text):
        text = text.replace("```json", "").replace("```", "").strip()
        matches = re.findall(r'\{.*?\}', text, re.DOTALL)
        if matches:
            for match in reversed(matches):
                try: return json.loads(match)
                except: 
                    try: return ast.literal_eval(match)
                    except: pass
        return None

    def get_element_signature(self, el, tag):
        """Creates a unique hash for an element to detect loops."""
        return f"{tag}_{el.location['x']}_{el.location['y']}"

    def analyze_page(self):
        """
        SMART SCANNER:
        1. Identifies 'Main Content' vs 'Navigation'.
        2. Filters out noise (footer links, tiny icons).
        """
        # We prioritize specific tags relevant to the task
        elements = self.driver.find_elements(By.CSS_SELECTOR, 
            "main button, main a, main input, div[role='main'] button, " + 
            "h1, h2, h3, p, label, input, button, a[href], textarea")
        
        visual_lines = []
        element_map = {}
        id_counter = 0
        
        # Keywords that suggest an element is "Navigation Noise"
        nav_keywords = ["home", "tutorial", "exercises", "get certified", "login", "sign up", "menu"]
        
        for el in elements:
            if not el.is_displayed(): continue
            
            tag = el.tag_name
            text = el.text.strip()
            aria = el.get_attribute("aria-label") or ""
            full_text = (text + " " + aria).strip()
            
            # --- FILTER 1: Skip Empty or Tiny Elements ---
            if len(full_text) < 2 and tag != 'input': continue
            
            # --- FILTER 2: Heuristic Classification ---
            is_nav = False
            # Check if inside a <nav> or header (simple check via parent)
            # This is slow in selenium, so we use text heuristics instead
            if any(k in full_text.lower() for k in nav_keywords) and len(full_text) < 15:
                is_nav = True
                
            # --- BUILD VISUAL MAP ---
            if tag in ['a', 'button', 'input', 'textarea', 'label'] or el.get_attribute("onclick"):
                id_counter += 1
                
                if id_counter in self.banned_ids: continue

                element_map[id_counter] = el
                
                # Markers help the LLM prioritize
                marker = "[NAV]" if is_nav else "[CONTENT]"
                if "start" in full_text.lower() or "next" in full_text.lower() or "submit" in full_text.lower():
                    marker = "🔥 [PRIORITY]" # Highly relevant for quizzes
                
                # Capture input values
                val = el.get_attribute("value")
                if val and tag in ['input', 'textarea']:
                    full_text += f" (Value: '{val}')"

                visual_lines.append(f"{marker} [{id_counter}] <{tag}> {full_text[:80]}")
            
            # Context text (Questions, Instructions)
            elif tag in ['h1', 'h2', 'h3', 'p', 'legend'] and len(full_text) > 10:
                # Deduplicate
                if not any(full_text[:20] in line for line in visual_lines[-3:]):
                    visual_lines.append(f"📝 {full_text[:120]}")

            if id_counter >= 70: break # Hard limit to save tokens

        return "\n".join(visual_lines), element_map

    def execute_action(self, action_id, element_map, action_type="click", input_text=""):
        el = element_map.get(action_id)
        if not el: return False, "ID not found"

        try:
            self.driver.execute_script("arguments[0].style.border='3px solid red'; arguments[0].scrollIntoView({block: 'center'});", el)
            time.sleep(0.5)

            if action_type == "click":
                try: el.click()
                except: self.driver.execute_script("arguments[0].click();", el)
                return True, "Clicked"

            elif action_type == "type":
                el.clear()
                el.send_keys(input_text)
                # Sometimes we need to click "Search" after typing, but Enter usually works
                el.send_keys(Keys.RETURN) 
                return True, f"Typed '{input_text}'"
        
        except Exception as e:
            self.banned_ids.append(action_id)
            return False, str(e)

    def run(self, goal):
        print(f"\n🧠 INTELLIGENT AGENT V3 STARTED.\nGoal: {goal}")
        
        # 1. URL EXTRACTION & JUMP
        url_match = re.search(r'(https?://[^\s]+)', goal)
        if url_match:
            self.target_url = url_match.group(0)
            print(f"🔗 Detected Target URL: {self.target_url}")
            self.driver.get(self.target_url)
        else:
            self.driver.get("https://www.google.com")

        # MAIN LOOP
        consecutive_same_url = 0
        last_url = ""

        for step in range(30):
            time.sleep(4)
            current_url = self.driver.current_url
            print(f"\n--- STEP {step+1} ---")
            print(f"📍 {current_url}")
            
            # --- SENTRY MODE: URL DRIFT CHECK ---
            # If we had a target URL, but we drifted to a generic tutorial page, GO BACK.
            if self.target_url and "w3schools.com" in self.target_url:
                # If we are on default.asp or html_exercises.asp but WANTED quiztest.asp
                if "quiztest.asp" in self.target_url and "quiztest.asp" not in current_url:
                    print("⚠️ DRIFT DETECTED! We left the Quiz page. Returning to target...")
                    self.driver.get(self.target_url)
                    continue

            # --- LOOP DETECTION ---
            if current_url == last_url:
                consecutive_same_url += 1
            else:
                consecutive_same_url = 0
            last_url = current_url
            
            # If stuck on same page for 3 turns, clear bans and force re-think
            if consecutive_same_url > 3:
                print("⚠️ Stuck on same page. Clearing bans to try fresh.")
                self.banned_ids = [] 
            
            # PERCEIVE
            page_content, element_map = self.analyze_page()
            
            if not page_content:
                print("❌ Page empty. Retrying...")
                continue

            # THINK (Stateless Prompt)
            # We recreate the prompt fresh every time to keep Context Window small
            prompt = f"""
            You are a Web Surfing AI. 
            GOAL: "{goal}"
            CURRENT URL: {current_url}
            
            LAST 3 ACTIONS: {self.action_log[-3:]}
            
            PAGE ELEMENTS:
            [NAV] = Navigation Link (AVOID unless necessary)
            [CONTENT] = Main Content (FOCUS here)
            🔥 [PRIORITY] = Buttons like Start, Next, Submit
            ------------------------------------------------
            {page_content}
            ------------------------------------------------
            
            RULES:
            1. If "Start Quiz" or "Next" exists, CLICK IT (🔥 [PRIORITY]).
            2. Ignore [NAV] links (like 'Home', 'Tutorials') if you are already on the target site.
            3. READ the 📝 text to answer questions.
            
            RETURN JSON ONLY:
            {{ "thought": "Reasoning here...", "action": "click", "id": 10 }}
            {{ "thought": "Reasoning...", "action": "type", "id": 5, "text": "value" }}
            """
            
            print("🧠 Thinking...")
            try:
                response = ollama.chat(model=MODEL_NAME, messages=[{'role': 'user', 'content': prompt}])
                result = self._extract_json(response['message']['content'])
            except Exception as e:
                print(f"LLM Error: {e}")
                continue
            
            if not result:
                print("⚠️ Brain freeze. Retrying...")
                continue

            # ACT
            thought = result.get("thought", "...")
            action = result.get("action")
            tid = result.get("id")
            text = result.get("text", "")
            
            print(f"💭 {thought}")
            print(f"⚡ {action} -> ID {tid}")
            
            if action == "finish": break
            
            success, msg = self.execute_action(tid, element_map, action, text)
            
            if success:
                self.action_log.append(f"{action.upper()} ID {tid}")
                # Loop Prevention: If we clicked this ID recently and URL didn't change, ban it
                if consecutive_same_url > 1:
                     print(f"⚠️ Page didn't change. Banning ID {tid} for next turn.")
                     self.banned_ids.append(tid)
            else:
                print(f"❌ Failed: {msg}")

# --- RUN ---
if __name__ == "__main__":
    bot = IntelligentAgent()
    task = "find about Tesla and make a very very detailed report by browsering and gathering the info and make report at last"
    try:
        bot.run(task)
    finally:
        bot.driver.quit()